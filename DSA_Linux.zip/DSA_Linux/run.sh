#!/bin/sh

exec mono "./DSA.exe" "$@"
